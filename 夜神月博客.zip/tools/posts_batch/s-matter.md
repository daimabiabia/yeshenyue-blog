# Matter 之路：一颗灯泡同时接入 HA 与 Apple Home

> Matter 最打动人的能力是"多重管理员"：同一颗灯，Siri 控得了，HA 也控得了，互不冲突。实际接入走一遍，把坑踩完。

## 一、准备清单

- 一颗 Matter 设备（ Thread 或 WiFi，本文用 Thread 灯泡示范）
- Home Assistant（2024.x+）+ **Thread 边界路由器**（Home Assistant Connect ZBT-1 或任意 OTBR）
- iPhone（Apple Home 测试用）

关键认知：**Thread 设备必须加入某个 Thread 网络**（由边界路由器创建），Matter 只是跑在 Thread 之上的应用层。没有边界路由器 = 灯泡永远配不上。

## 二、接入 HA（第一生态）

```
1. 灯泡恢复出厂（长按 10s）
2. 扫灯泡上的 Matter 二维码，记录 11 位手工配对码
3. HA：设置 → 设备与服务 → 添加集成 → Matter → "使用配对码添加"
4. 填入配对码 → 等待 30~120s（Thread 设备首次入网较慢）
5. 出现实体 light.xxx
```

## 三、同时接入 Apple Home（多重管理员）

```
1. HA 里该 Matter 设备 → 齿轮 → "与其它服务共享"
2. 生成一个共享配对码
3. iPhone 家庭 App → 添加配件 → 输入该码
4. 灯泡在两个生态同时在线 ✔
```

两个生态各自持有独立凭证（各自 Fabric），互不知晓也互不干扰——这就是 Matter 的多管理员架构。**共享的是设备本身，不是 HA 的控制权。**

## 四、真实坑位（按出现频率排序）

1. **Thread 边界路由器分裂**：家里有 HomePod mini + HA OTBR 两台路由器 → 两个 Thread 网络互不相通，设备在哪个网取决于先加入哪个。**只保留一个活跃边界路由器**，其余当普通 Thread 设备。
2. **配对码被用旧**：二维码上的码只用于"首次入网"，设备已入网后要用"共享码"。直接用原始码 → 一直失败。
3. **iPhone 家庭 App 里设备"无响应"**：手机走蜂窝网络 + 家庭中枢（HomePod/AppleTV）不在家/版本旧。Thread 设备控制依赖家庭中枢。
4. **HA 重装后设备失联**：Matter 控制器的密钥丢了 → 设备还认旧控制器。恢复备份或设备重新配对。
5. **WiFi Matter 设备配对慢**：2.4G 信道拥挤时 BLE 配网阶段超时，先把手机贴近设备、路由器 2.4G 负载低谷时配。

## 五、固件更新与认证

- **OTA**：Matter OTA 由"供应商分发"，家庭侧的 HA 可以给自建设备推 OTA；买来的设备跟厂商 App/云端节奏。
- **VID/PID**：自研设备测试用 VID 0xFFF1；进生态白名单（尤其 Google/Alexa）需要正式认证，个人玩家 HA 侧无门槛。

## 六、自建 ESP32 Matter 设备（顺带一提）

ESP32-H2（Thread）+ esp-matter SDK：

```bash
# ESP-IDF 环境
idf.py set-target esp32h2
idf.py menuconfig   # 启用 Matter 示例（light）
idf.py build flash
# 配对：扫描设备串口打印的二维码 → HA 添加
```

从"能配对"到"量产稳定"还差：安全启动、DAC 设备证明证书、断网重连策略。个人项目做到"稳定配对 + 断电恢复 + OTA 可升级"即可满意。

## 七、要不要现在全面 Matter 化？

务实建议：

- 新买设备：优先带 Matter 标志（面向未来 + 双生态）。
- 存量 Zigbee：Z2M 仍是最优解，别为了 Matter 重新配对一遍。
- 关键场景（门锁/告警）：本地协议 + HA 自动化仍是延迟最低方案。
- Thread 网络规划先于设备采购：边界路由器选型（HA ZBT-1 / HomePod / OTBR）决定体验上限。

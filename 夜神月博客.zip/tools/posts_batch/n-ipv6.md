# IPv6 落地物联网：地址规划、直连与安全边界

> 运营商已经大规模派发 IPv6，IoT 设备天然适配"每设备一个公网地址"的理念——但直连世界的同时，防火墙边界要重新想。

## 一、IoT 为什么需要 IPv6

1. **地址焦虑消失**：IPv4 下做端口映射、内网穿透、中继都源于地址不够。IPv6 下每台设备可拥有全球唯一地址，点对点直达。
2. **NAT 穿透消失**：UDP/CoAP 设备直连，延迟与复杂度双降。
3. **6LoWPAN/Thread**：低功耗协议栈原生基于 IPv6（这是 Thread 的地基）。
4. **端到端加密**：无需 NAT 中间人，DTLS 直达。

## 二、地址规划：不再是 192.168 的小学算术

IPv6 地址 128 位，子网 /64 是最小分配单位——**一个家庭拿到的 /56 或 /48 足够分 256~65536 个 /64 子网**。

```
2001:db8:aaaa:1::/64   ← 信任区（电脑、手机）
2001:db8:aaaa:2::/64   ← IoT 区
2001:db8:aaaa:3::/64   ← 访客区
```

设备地址两种模式：

| 模式 | 形式 | 适用 |
|---|---|---|
| SLAAC（无状态） | 前缀 + EUI-64/MAC 衍生 | 免配置，默认 |
| 固定后缀 | `2001:db8:aaaa:2::101` | 防火墙规则好写，推荐 IoT 用 |

IoT 设备建议**固定后缀 + DHCPv6 或手动配置**——防火墙按后缀放行，可读可审计。

## 三、安全边界：公网可达 ≠ 公网可访问

最大的认知误区：设备有公网 IPv6 就"暴露"了。真正的暴露面由防火墙决定：

```
# OpenWrt ip6tables 示例：IoT 区默认拒绝入站
ip6tables -A FORWARD -i wan -d 2001:db8:aaaa:2::/64 -j DROP
ip6tables -A FORWARD -i trusted -d 2001:db8:aaaa:2::/64 -j ACCEPT   # 家内可管

# 例外：某设备只开放指定端口给特定来源
ip6tables -A FORWARD -i wan -d 2001:db8:aaaa:2::101 -p tcp --dport 8883 -s 2001:db8:cloud::/48 -j ACCEPT
```

**纪律**：
1. IoT 区入站默认全拒，远比 IPv4 的"只挡 WAN 口"要细——IPv6 下每个设备都是"边缘"，规则要下放到设备组。
2. 设备固件必须自带最小服务面：不开 telnet/23、不开调试 80 调试页面到公网。
3. 邻居发现协议（NDP）安全：路由器上开 RA Guard，防伪造网关。

## 四、设备端配置（ESP32 示例）

```cpp
// ESP-IDF 启用 IPv6（lwIP 默认支持，需开启 SLAAC）
esp_netif_create_ip6_linklocal(esp_netif);
// 等待全球地址就绪
esp_netif_ip6_info_t ip6;
esp_netif_get_ip6_global(esp_netif, &ip6);
// MQTT 直连 IPv6 broker
esp_mqtt_client_config_t cfg = {
  .broker.address.uri = "mqtts://2001:db8:cloud::10:8883",
};
```

坑速查：
1. **DNS AAAA 优先策略**：双栈设备默认 Happy Eyeballs，IPv6 不通自动回 IPv4——但 UDP 自定义协议没有这个机制，需自己做回退。
2. **地址变化**：前缀由运营商派发会变（重拨就换），设备侧必须有"前缀变了重新注册"逻辑（按域名+DDNS 而非硬编码地址）。
3. **防火墙只挡入站不挡出站**的默认策略在 IoT 上是错的：出站也要限制（设备被反噬后对外扫描）。

## 五、家庭落地清单

- [ ] 路由器开 IPv6（光猫桥接+路由拨号，别用光猫路由模式的老固件）
- [ ] IoT 区独立 /64 + 入站默认拒
- [ ] 需要公网可达的设备用固定后缀 + 精确放行
- [ ] 远程访问仍走 WireGuard（IPv6 让 VPN 更简单：直连无 NAT）
- [ ] 路由器防火墙日志保留，季度审一次
